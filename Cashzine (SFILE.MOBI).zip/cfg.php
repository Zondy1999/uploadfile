<?php

//MASUKAN DATA BALLANCE MILIK KALIAN!!!
$databallance = "xxxxxxx";

//MASUKAN DATA CLAIM MILIK KALIAN!!!
$dataclaim = "xxxxxxx";
